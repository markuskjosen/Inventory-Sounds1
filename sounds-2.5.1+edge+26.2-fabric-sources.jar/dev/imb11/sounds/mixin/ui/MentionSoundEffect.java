package dev.imb11.sounds.mixin.ui;

import dev.imb11.mru.LoaderUtils;
import dev.imb11.sounds.SoundsClient;
import dev.imb11.sounds.config.ChatSoundsConfig;
import dev.imb11.sounds.config.SoundsConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.client.multiplayer.chat.GuiMessageSource;
import net.minecraft.client.multiplayer.chat.GuiMessageTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MessageSignature;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.regex.PatternSyntaxException;

@Mixin(ChatComponent.class)
public class MentionSoundEffect {
    @Shadow
    @Final
    private Minecraft minecraft;

    @Unique
    private float sounds$cooldownPeriod = 0f;

    @Inject(method = "extractRenderState(Lnet/minecraft/client/gui/components/ChatComponent$ChatGraphicsAccess;IILnet/minecraft/client/gui/components/ChatComponent$DisplayMode;)V", at = @At("HEAD"))
    public void $cooldown_period(ChatComponent.ChatGraphicsAccess graphics, int screenHeight, int ticks, ChatComponent.DisplayMode displayMode, CallbackInfo ci) {
        if (sounds$cooldownPeriod > 0) {
            sounds$cooldownPeriod -= this.minecraft.getDeltaTracker().getGameTimeDeltaPartialTick(true);
        }
    }

    @Inject(method = "addMessage", at = @At("HEAD"), cancellable = false)
    public void $mention_recieve_sound_effect(Component message, MessageSignature signature, GuiMessageSource source, GuiMessageTag indicator, CallbackInfo ci) {
        if (sounds$cooldownPeriod > 0 && (SoundsConfig.get(ChatSoundsConfig.class).enableChatSoundCooldown || LoaderUtils.isModInstalled("chatpatches"))) {
            return;
        }

        sounds$cooldownPeriod = (LoaderUtils.isModInstalled("chatpatches") ? 0.01f : SoundsConfig.get(ChatSoundsConfig.class).chatSoundCooldown) * 20f;

        String messageString = message.getString();

        // Generate regex from mentionKeywords
        StringBuilder regex = new StringBuilder();
        regex.append("(?i).*(");
        for (String keyword : SoundsConfig.get(ChatSoundsConfig.class).mentionKeywords) {
            regex.append(keyword).append("|");
        }
        regex.deleteCharAt(regex.length() - 1);
        regex.append(").*");

        boolean isMention;
        try {
            isMention = messageString.matches(regex.toString());
        } catch (PatternSyntaxException e) {
            SoundsClient.LOGGER.error("Invalid mention expression", e);
            isMention = false;
        }


        if (SoundsConfig.get(ChatSoundsConfig.class).ignoreSystemChats) {
            if (indicator == GuiMessageTag.system() || indicator == GuiMessageTag.chatError()) {
                return;
            }
        }

        if (isMention)
            SoundsConfig.get(ChatSoundsConfig.class).mentionSoundEffect.playSound(true);
        else SoundsConfig.get(ChatSoundsConfig.class).messageSoundEffect.playSound();
    }
}
